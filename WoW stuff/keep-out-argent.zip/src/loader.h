void AddTorneoArgentaScripts();
