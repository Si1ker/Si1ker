
void AddcfinstanceScripts();
