#include "Configuration/Config.h"
#include "ScriptMgr.h"
#include "Player.h"
#include "Battleground.h"
#include "GroupMgr.h"
#include "Group.h"
#include "World.h"

enum playerMorphs
{
    //MALE
    FAKE_M_TAUREN = 20585,
    FAKE_M_NELF = 20318,
    FAKE_M_HUMAN = 19723,
    FAKE_M_BELF = 20578,
    FAKE_M_DWARF = 20317,
    FAKE_M_TROLL = 20321,

    //FEMALE
    FAKE_F_ORC = 20316,
    FAKE_F_GNOME = 20320,
    FAKE_F_BELF = 20579,
    FAKE_F_DRAENEI = 20323,
    FAKE_F_HUMAN = 19724,
    FAKE_F_TAUREN = 20584,
};
uint32 m_FakeMorph;

class MapFaction : public DataMap::Base
{
public:
    MapFaction() {}
    MapFaction(uint32 MapTeam, uint32 MapFaction, uint32 PlayerFaction) : MapTeam(MapTeam), PlayerFaction(PlayerFaction) {}
    uint32 MapTeam = TEAM_NEUTRAL;
    uint32 PlayerFaction = 0;
};

class CFInstancePlayerScript : public PlayerScript
{
public:
    CFInstancePlayerScript() : PlayerScript("CrossFactionInstance") { }

    void OnMapChanged(Player* player)
    {
        if (sWorld->getBoolConfig(CONFIG_ALLOW_TWO_SIDE_INTERACTION_GROUP) == true)
        {
            Map* map = player->GetMap();
            Map::PlayerList const &playerList = map->GetPlayers();
            MapFaction* factionMap = map->CustomData.GetDefault<MapFaction>("MapFaction");

            if (map->IsBattlegroundOrArena())
                return;

            if (map->Is25ManRaid() || map->IsDungeon() || map->IsRaid() || map->IsRaidOrHeroicDungeon())
            {
                if (factionMap->MapTeam == TEAM_NEUTRAL)
                {
                    factionMap->MapTeam = playerList.getLast()->GetSource()->GetTeamId();
                    factionMap->PlayerFaction = playerList.getLast()->GetSource()->getFaction();
                }

                if (player->GetTeamId() != factionMap->MapTeam)
                {
                    player->setFaction(factionMap->PlayerFaction);
                    setfakemorph(player);
                    player->SetDisplayId(m_FakeMorph);
                    player->SetNativeDisplayId(m_FakeMorph);
                }
            }
            else
            {
                player->setFactionForRace(player->getRace());
                player->InitDisplayIds();
            }
        }
    }

    void setfakemorph(Player* p)
    {
        switch (p->getRace())
        {
            break;
        case RACE_NIGHTELF:
            if (p->getClass() == CLASS_DRUID)
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_TAUREN : FAKE_F_TAUREN;
            else
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_BELF : FAKE_F_ORC;
            break;
        case RACE_DRAENEI:
            if (p->getClass() == CLASS_SHAMAN)
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_TROLL : FAKE_F_ORC;
            else
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_BELF : FAKE_F_BELF;
            break;
        case RACE_UNDEAD_PLAYER:
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_TROLL : FAKE_F_ORC;
            break;
        case RACE_GNOME:
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_BELF : FAKE_F_BELF;
            break;
        case RACE_HUMAN:
        case RACE_DWARF:
            m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_TROLL : FAKE_F_ORC;
            break;
        case RACE_TROLL:
        case RACE_ORC:
            if (p->getClass() == CLASS_SHAMAN)
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_DWARF : FAKE_F_DRAENEI;
            else
                m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_DWARF : FAKE_F_HUMAN;
        case RACE_TAUREN:
            m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_NELF : FAKE_F_ORC;
            break;
        case RACE_BLOODELF:
            m_FakeMorph = p->getGender() == GENDER_MALE ? FAKE_M_HUMAN : FAKE_F_HUMAN;
            break;
        }
    }
};

void AddcfinstanceScripts()
{
    new CFInstancePlayerScript();
}
